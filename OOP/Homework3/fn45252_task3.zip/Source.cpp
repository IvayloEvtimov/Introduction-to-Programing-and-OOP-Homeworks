/////////////
//author: Ivaylo Evtimov
//fn: 45252
//Task 3
//compilator: VC
////////////////


#include <iostream>

#include "Helper.h"

int main()
{
	start();

	system("pause");
	return 0;
}